$(function() {

    $('td').resizable({
        alsoResize: "#astor img",
    minWidth:100,
    minHeight: 50
    });
});
